<!-- hero section -->
<section class="about__hero__section position-relative">
    <div class="container h-100 d-flex align-items-center justify-content-start">
        <div class="text__intro">
            <h1 class="text-uppercase">it's all about knowledge and informaiton</h1>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                Ipsam, incidunt voluptatum consectetur repellendus fugit id.
                Ipsam, incidunt voluptatum consectetur repellendus fugit id.
            </p>
            <a href="" class="join__link mt-4 d-flex align-items-center justify-content-center text-capitalize text-decoration-none">join us</a>
        </div>
    </div>
</section><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/includes/about__hero.blade.php ENDPATH**/ ?>