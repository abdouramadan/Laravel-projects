<?php $__env->startSection('title'); ?> Post Page <?php $__env->stopSection(); ?>

<?php $no__header_height = true; ?>


<?php $__env->startSection('content'); ?>
<!-- blog section -->
<main class="blog__section single__post">
    <section class="container">
        <div class="row flex-lg-nowrap flex-md-wrap">
            <!-- holder -->
            <div class="blog__holder p-0 col-lg-8 flex-md-12">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-capitalize-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <!-- post 01 -->
                <div class="post bg-white shadow-sm">
                    <!-- post image -->
                    <div class="post__img">
                        <?php if($post->image != '0'): ?>
                        <img src="<?php echo e(asset('admin/posts/'.$post->image)); ?>" alt="post__img">
                        <?php else: ?>
                        <img src="<?php echo e(asset('home/img/bg.jpg')); ?>" alt="post__img">
                        <?php endif; ?>
                    </div>
                    <!-- post info -->
                    <div class="post__info w-100 d-flex align-items-center flex-wrap my-3">
                        <div class="date d-flex align-items-center">
                            <span class="icon mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                            <span class="text"><?php echo e($post->created_at); ?></span>
                        </div>
                        <div class="author d-flex align-items-center mx-lg-3">
                            <span class="icon mr-2"><ion-icon name="person-outline"></ion-icon></span>
                            <span class="text text-capitalize"><?php echo e($post->author); ?></span>
                        </div>
                        <div class="author d-flex align-items-center">
                            <span class="icon mr-2"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                            <span class="text text-capitalize">20 comments</span>
                        </div>
                        <div class="author d-flex align-items-center ml-3">
                            <span class="icon mr-2"><ion-icon name="pricetags-outline"></ion-icon></span>
                            <span class="text text-capitalize"><?php echo e($post->tag); ?></span>
                        </div>
                    </div>
                    <!-- post title -->
                    <h3 class="post__title text-capitalize"><?php echo e($post->title); ?></h3>
                    <!-- post body -->
                    <div class="post__body"><?php echo $post->body; ?></div>
                    <!-- post footer -->
                    <div class="post__footer d-flex align-items-center mt-5">
                        <div class="post__tags d-flex align-items-center">
                            <h3 class="text-capitalize mr-3 p-0 mb-0">tags : </h3>
                            <ul class="tags__list d-flex align-items-center p-0 m-0">
                                <a href="<?php echo e(route('Cat', ['cat'=>$post->tag])); ?>" class="tag__link d-flex align-items-center justify-content-center text-decoration-none"><?php echo e($post->tag); ?></a>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- comments container -->
                <div class="comments mt-5 shadow-sm">
                    <h3 class="text-capitalize mb-5">recent comments</h3>

                    <div class="comments__wrapper">
                        <?php $__currentLoopData = $postComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- comment 01 -->
                        <div class="comment__item d-flex align-items-start">
                            <!-- user image -->
                            <div class="commenter__img rounded-circle">
                                <img src="<?php echo e(asset('home/img/default-user.jpg')); ?>" class="w-100 h-100 rounded-circle" alt="">
                            </div>
                            <!-- comment info -->
                            <div class="comment__info pl-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <h4 class="commenter__name text-capitalize"><?php echo e($comment->username); ?></h4>
                                    <span class="comment__date text-capitalize d-flex align-items-center">
                                        <ion-icon name="calendar-outline" class="mr-2"></ion-icon>
                                        <small><?php echo e($comment->created_at); ?></small>
                                    </span>
                                </div>
                                <div class="comment__body"><?php echo $comment->body; ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- comment form -->
                <div class="comment__form bg-white mt-5 shadow-sm" id="form">
                    <h3 class="text-capitalize mb-3">leave comment</h3>

                    <form action="<?php echo e(route('CreateComment', ['id'=>$post->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="username" class="text-capitalize">sername</label>
                            <input type="text" name="username" class="form-control">
                        </div>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form-group">
                            <label for="email" class="text-capitalize">email address</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="form-group">
                            <label for="body" class="text-capitalize">comment body</label>
                            <textarea name="body" id="editor" class="form-control"></textarea>
                        </div>
                        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <button class="d-flex align-items-center justify-content-center text-capitalize">post comment</button>
                    </form>
                </div>
            </div>
            <?php echo $__env->make('home.includes.aside__container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/pages/post.blade.php ENDPATH**/ ?>