<?php $hero__name = 'contact__hero'; ?>

<?php $__env->startSection('title'); ?> Contact <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- contact section -->
<main class="contact__me px-0">
    <div class="container">
        <form action="" class="shadow-sm p-3 border rounded w-100">
            <h3 class="text-capitalize mb-5">contact us</h3>
            <div class="form-group">
                <label for="username">username</label>
                <input type="text" name="username" class="form-control">
            </div>
            <div class="form-group">
                <label for="subject">subject</label>
                <input type="text" name="subject" class="form-control">
            </div>
            <div class="form-group">
                <label for="email">email address</label>
                <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <label for="contact__body">message content</label>
                <textarea name="contact__body" class="form-control"></textarea>
            </div>
            <button class="d-flex align-items-center justify-content-center text-capitalize">contact us</button>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/pages/contact.blade.php ENDPATH**/ ?>