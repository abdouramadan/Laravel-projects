<?php $__env->startSection('title'); ?> Comments <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="comments__page">
		<div class="text__intro shadow d-inline-flex align-items-center mt-3">
			<span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="chatbubbles-outline"></ion-icon></span>
			<h3 class="text-capitalize p-0 m-0">all comments</h3>
        </div>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-capitalize mt-3 p-3"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>

		
		<div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="comment col-lg-6 col-md-12 p-0 p-lg-2 p-sm-0">
                <div class="inner__item w-100 p-3 shadow-sm bg-white">
                    <div class="comment-info d-flex align-items-center justify-content-between flex-wrap">
                        <p class="name text-capitalize p-0 m-0 d-flex align-items-center">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
                            <span><?php echo e($comment->username); ?></span>
                        </p>
                        <p class="date p-0 m-0 d-flex align-items-center">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                            <span><?php echo e($comment->created_at); ?></span>
                        </p>
                        <p class="email p-0 m-0 d-flex align-content-around w-100 mt-2">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
                            <span><?php echo e($comment->email); ?></span>
                        </p>
                        <div class="body my-3 w-100"><?php echo $comment->body; ?></div>
                        <div class="actions d-flex align-items-center">
                            <?php if($comment->status == '1'): ?>
							<a href="<?php echo e(url('blog', [$comment->post_slug])); ?>" class="action__link visit__comment d-flex align-items-center justify-content-center text-capitalize text-decoration-none">visit</a>
                            <?php endif; ?>
							<a href="<?php echo e(route('DeleteComment', ['id'=>$comment->id])); ?>" class="action__link delete__comment d-flex align-items-center justify-content-center text-capitalize text-decoration-none mx-2">delete</a>
                            <?php if($comment->status == '0'): ?>
							<a href="<?php echo e(route('ProveComment', ['id'=>$comment->id])); ?>" class="action__link upprove__comment d-flex align-items-center justify-content-center text-capitalize text-decoration-none">upprove</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($comments) < 1): ?>
            <div class="alert alert-info text-capitalize w-100 p-3">no comments found</div>
            <?php endif; ?>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/admin/pages/comments.blade.php ENDPATH**/ ?>