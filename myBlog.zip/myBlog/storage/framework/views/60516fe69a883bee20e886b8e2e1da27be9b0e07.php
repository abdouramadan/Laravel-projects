<!-- aside container -->
<aside class="aside__box col-lg-4 ml-lg-3 flex-md-12 p-0">
<!-- serach bar -->
<form action="<?php echo e(route('Search')); ?>" method="POST" class="d-flex align-items-center justify-content-center p-3 shadow-sm bg-white">
    <?php echo csrf_field(); ?>
    <div class="form-group d-flex align-items-center justify-content-center w-100 m-0">
        <input type="text" name="s" class="form-control rounded-0" placeholder="search">
        <button class="btn rounded-0 d-flex align-items-center justify-content-center p-0">
            <span class="icon"><ion-icon name="search-outline"></ion-icon></span>
        </button>
    </div>
</form>

<!-- categories -->
<div class="categories my-4 d-flex flex-wrap align-items-center justify-content-center p-3 shadow-sm bg-white">
    <h3 class="text-capitalize w-100 mb-3">categories</h3>
    <ul class="nav d-flex flex-column w-100">
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'web design'])); ?>" class="nav-link text-capitalize p-0">web design</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'computer'])); ?>" class="nav-link text-capitalize p-0">computer</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'news'])); ?>" class="nav-link text-capitalize p-0">news</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'education'])); ?>" class="nav-link text-capitalize p-0">education</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'english'])); ?>" class="nav-link text-capitalize p-0">english</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'religion'])); ?>" class="nav-link text-capitalize p-0">religion</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'science'])); ?>" class="nav-link text-capitalize p-0">science</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'programming'])); ?>" class="nav-link text-capitalize p-0">programming</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'culture'])); ?>" class="nav-link text-capitalize p-0">culture</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'fun'])); ?>" class="nav-link text-capitalize p-0">fun</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('Cat', ['cat'=>'others'])); ?>" class="nav-link text-capitalize p-0">others</a>
        </li>
    </ul>
</div>

<!-- latest posts -->
<div class="latest__posts d-flex align-items-center justify-content-center p-3 shadow-sm bg-white flex-wrap">
    <h3 class="text-capitalize w-100 mb-3">latest posts</h3>

    <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- post 01 -->
    <a href="<?php echo e(url('blog', [$post->slug])); ?>" class="post__item text-decoration-none w-100 d-flex align-items-center">
        <div class="post__img">
            <?php if($post->image != '0'): ?>
            <img src="<?php echo e(asset('admin/posts/'.$post->image)); ?>" class="w-100 h-100" alt="post__img">
            <?php else: ?>
            <img src="<?php echo e(asset('home/img/bg.jpg')); ?>" class="w-100 h-100" alt="post__img">
            <?php endif; ?>
        </div>
        <div class="post__info d-flex flex-column justify-content-center pl-2">
            <h4 class="post__title text-capitalize"><?php echo e($post->title); ?></h4>
            <p class="p-0 m-0 d-flex flex-column align-items-start">
                <span class="post__author text-capitalize mb-1"><?php echo e($post->author); ?></span>
                <small class="post__date"><?php echo e($post->created_at); ?></small>
            </p>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(count($latestPosts) < 1): ?>
        <div class="alert alert-info w-100 text-capitalize p-3">no posts found! ...</div>
    <?php endif; ?>

</div>

<!-- tags
<div class="tags my-4 d-flex align-items-center justify-content-center p-3 shadow-sm bg-white flex-wrap">
    <h3 class="text-capitalize w-100 mb-3">tags</h3>
    <div class="tags__box d-flex align-items-center flex-wrap">
        <a href="" class="tag__item text-capitalize d-flex align-items-center justify-content-center text-decoration-none">web design</a>
        <a href="" class="tag__item text-capitalize d-flex align-items-center justify-content-center text-decoration-none">news</a>
        <a href="" class="tag__item text-capitalize d-flex align-items-center justify-content-center text-decoration-none">fun</a>
        <a href="" class="tag__item text-capitalize d-flex align-items-center justify-content-center text-decoration-none">programming</a>
    </div>
</div> -->
</aside>
<?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/includes/aside__container.blade.php ENDPATH**/ ?>