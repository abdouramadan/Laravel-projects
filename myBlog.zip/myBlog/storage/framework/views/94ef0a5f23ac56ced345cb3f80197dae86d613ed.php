

<?php $hero__name = 'about__hero'; $about__header = 'about__header'; ?>

<?php $__env->startSection('title'); ?> About me <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- about me section -->
<main class="about__me">
    <div class="container">
        <div class="row align-items-center">

            <!-- about features -->
            <div class="col-lg-6 col-md-12 about__features d-flex">
                <!-- box two -->
                <div class="box__on d-flex flex-column align-items-center w-50">
                    <!-- item 01 -->
                    <div class="item shadow-sm w-100 d-flex flex-column align-items-center justify-content-center text-center">
                        <span class="icon d-flex align-items-baseline justify-content-center"><ion-icon name="code-slash-outline"></ion-icon></span>
                        <h3 class="text-capitalize">porgrammer</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, obcaecati?</p>
                    </div>
                    <!-- item 02 -->
                    <div class="item shadow-sm w-100 d-flex flex-column align-items-center justify-content-center text-center">
                        <span class="icon d-flex align-items-baseline justify-content-center"><ion-icon name="color-palette-outline"></ion-icon></span>
                        <h3 class="text-capitalize">ui/ux designer</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, obcaecati?</p>
                    </div>
                </div>

                <!-- box two -->
                <div class="box__two d-flex flex-column align-items-center w-50 pl-2">
                    <!-- item 01 -->
                    <div class="item shadow-sm w-100 d-flex flex-column align-items-center justify-content-center text-center">
                        <span class="icon d-flex align-items-baseline justify-content-center"><ion-icon name="laptop-outline"></ion-icon></span>
                        <h3 class="text-capitalize">hoby</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, obcaecati?</p>
                    </div>
                    <!-- item 02 -->
                    <div class="item shadow-sm w-100 d-flex flex-column align-items-center justify-content-center text-center">
                        <span class="icon d-flex align-items-baseline justify-content-center"><ion-icon name="library-outline"></ion-icon></span>
                        <h3 class="text-capitalize">passionate for learning</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, obcaecati?</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 about__text pl-3">
                <h2 class="text-capitalize mb-3">a bit about me</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    Minus quia maxime eligendi sed. Et iusto quidem provident adipisci porro possimus.
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    Ipsa ab saepe corrupti porro dolore nihil laborum reprehenderit, incidunt distinctio accusamus, 
                    voluptatibus quasi deserunt obcaecati sunt fugiat architecto repudiandae facilis totam?
                </p>
                <a href="" class="services__link mt-3 text-decoration-none d-flex align-items-center justify-content-center">what we do?</a>
            </div>
        </div>
    </div>
</main>

<!-- services section -->
<main class="services">
    <div class="container">
        <div class="row align-items-center">
            <div class="services__text col-lg-6 col-md-12">
                <h3 class="text-capitalize">what we provide</h3>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod ducimus explicabo recusandae 
                    temporibus beatae exercitationem culpa voluptatibus vel rerum sequi.
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    Ipsa in officia aspernatur animi explicabo sapiente ipsum possimus. Veritatis, fugiat est. 
                    Consectetur veritatis porro fuga, atque reiciendis adipisci eveniet nesciunt voluptate.
                </p>
            </div>
            <div class="services__img col-lg-6 col-md-12">
                <img src="<?php echo e(asset('home/img/services__img.svg')); ?>" alt="">
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/pages/about.blade.php ENDPATH**/ ?>