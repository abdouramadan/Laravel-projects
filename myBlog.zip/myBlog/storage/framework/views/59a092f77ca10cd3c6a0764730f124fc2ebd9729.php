<?php $__env->startSection('title'); ?> Add Post <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="addPost__page p-lg-4 p-sm-1">
		<div class="text__intro shadow d-inline-flex align-items-center">
			<span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="newspaper-outline"></ion-icon></span>
			<h3 class="text-capitalize p-0 m-0">add post</h3>
		</div>

		<form action="<?php echo e(route('AddPost')); ?>" method="POST" class="p-lg-4 p-sm-1 shadow mt-5" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-capitalize"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
			
			<div class="form-group">
				<label for="title">post title</label>
				<input type="text" name="title" class="form-control">
            </div>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			
			<div class="form-group">
				<label for="title">post tag</label>
				<select name="tag" class="form-control">
					<option value=""></option>
					<option value="web design">web design</option>
					<option value="programming">programming</option>
					<option value="computer">computer</option>
					<option value="news">news</option>
					<option value="culture">culture</option>
					<option value="fun">fun</option>
					<option value="religion">religion</option>
					<option value="education">education</option>
					<option value="science">science</option>
					<option value="english">english</option>
					<option value="others">others</option>
				</select>
            </div>
            <?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			
			<div class="form-group">
				<label for="image">post image</label>
				<input type="file" name="image" class="form-control">
            </div>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			
			<div class="form-group">
				<label for="body">post body</label>
				<textarea name="body" id="editor" class="form-control"></textarea>
            </div>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			<button class="submit__btn">create</button>
		</form>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/admin/pages/addPost.blade.php ENDPATH**/ ?>