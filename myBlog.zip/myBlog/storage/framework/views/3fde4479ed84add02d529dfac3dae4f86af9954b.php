<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('home/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('home/css/app.css')); ?>">
    <style>
        .no__header_height {
            min-height: 70px !important;
        }
    </style>
</head>
<body>

    <?php $hero__name; $about__header; $no__header_height; ?>
    <!-- main header -->
    <header style="z-index: 2000" class="main__header shadow-sm <?php if(isset($no__header_height)): ?> no__header_height  <?php endif; ?> <?php if(isset($about__header)): ?> about__header  <?php endif; ?>">
        <!-- main navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-transparent p-0">
            <div class="container">
                <!-- logo -->
                <a href="<?php echo e(route('Home')); ?>" class="navbar-brand text-capitalize d-flex align-items-center justify-content-center">abdev</a>

                <!-- navbar toggler -->
                <button class="navbar-toggler" data-toggle="collapse" data-target="#mynav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- navbar list -->
                <div class="collapse navbar-collapse bg-white border-top p-3 position-relative" id="mynav" style="z-index: 2000">
                    <ul class="navbar-nav ml-auto" style="z-index: 2000">
                        <li class="nav-item active">
                            <a href="<?php echo e(route('Home')); ?>" class="nav-link text-capitalize">home</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('About')); ?>" class="nav-link text-capitalize">about</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('Contact')); ?>" class="nav-link text-capitalize">contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <?php if(isset($hero__name)): ?>
            <?php if($hero__name == 'home__hero'): ?>
                <?php echo $__env->make('home.includes.home__hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($hero__name == 'about__hero'): ?>
                <?php echo $__env->make('home.includes.about__hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($hero__name == 'contact__hero'): ?>
                <?php echo $__env->make('home.includes.contact__hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </header>


    <?php echo $__env->yieldContent('content'); ?>

    <!-- main footer -->
    <footer class="main__footer">
        <!-- top content -->
        <div class="to__content">
            <div class="container">
                <div class="row">
                    <!-- content one -->
                    <div class="content__one col-lg-4 col-md-6 mb-4 col-sm-12">
                        <div class="text">
                            <h3 class="text-capitalize mb-3">abdoudev</h3>
                            <p>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                Voluptates repellendus voluptatum assumenda nesciunt temporibus.
                                Aliquid nulla illum fugit laborum quo.
                            </p>
                        </div>
                        <div class="social__links d-flex align-items-center">
                            <a href="" class="link d-flex align-items-center justify-content-center text-white rounded-circle">
                                <ion-icon name="logo-facebook"></ion-icon>
                            </a>
                            <a href="" class="link mx-3 d-flex align-items-center justify-content-center text-white rounded-circle">
                                <ion-icon name="logo-twitter"></ion-icon>
                            </a>
                            <a href="" class="link d-flex align-items-center justify-content-center text-white rounded-circle">
                                <ion-icon name="logo-whatsapp"></ion-icon>
                            </a>
                        </div>
                    </div>
                    <!-- content two -->
                    <div class="content__two col-lg-4 col-md-6 mb-4 col-sm-12">
                        <h3 class="text-capitalize mb-3">contact us</h3>
                        <div class="text">
                            <p class="text-capitalize m-0">turkey - konya city - ali uliv dormitory</p>
                            <p class="p-0 m-0 my-1">+9923826373</p>
                            <p class="p-0 m-0">abdoudev36@gmail.com</p>
                            <p class="p-0 m-0 my-1">www.abdoudev.com</p>
                        </div>
                    </div>
                    <!-- content three -->
                    <div class="col-lg-4 quick__links text-capitalize col-md-12">
                        <h3 class="mb-3">quicl links</h3>
                        <div class="links__holder d-flex flex-column">
                            <a href="<?php echo e(route('Home')); ?>" class="link">home</a>
                            <a href="<?php echo e(route('About')); ?>" class="link">about me</a>
                            <a href="<?php echo e(route('Contact')); ?>" class="link">contact me</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- bottom content -->
        <div class="bottom__content">
            <div class="container d-flex align-items-center justify-content-center">
                <h3 class="text-capitalize p-0 m-0">copyright &copy; <script>const date = new Date(); document.write(date.getFullYear());</script> abdouedev</h3>
            </div>
        </div>
    </footer>

    <!-- javascript files -->
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
    <script src="https://cdn.ckeditor.com/4.14.1/basic/ckeditor.js"></script>
    <script src="<?php echo e(asset('home/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/layout/layout.blade.php ENDPATH**/ ?>