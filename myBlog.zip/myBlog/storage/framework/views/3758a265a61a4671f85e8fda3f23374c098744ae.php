<?php $__env->startSection('title'); ?> Update Profile <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="update__profile p-lg-4">
    <form action="<?php echo e(route('UpdateProfile', ['id'=>Session::get('id')])); ?>" method="POST" class="rounded shadow bg-white p-3">
        <?php echo csrf_field(); ?>

        <?php echo method_field('PUT'); ?>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-capitalize w-100"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger text-capitalize w-100"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>

        <h3 class="text-capitalize mb-3">update user account</h3>
        
        <div class="form-group">
            <label for="username" class="text-capitalize">username</label>
            <input type="text" name="username" class="form-control" value="<?php echo e(Session::get('username')); ?>" required>
        </div>
        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <div class="form-group">
            <label for="email" class="text-capitalize">email address</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(Session::get('email')); ?>" required>
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <input type="hidden" name="hidden_password" value="<?php echo e(Session::get('password')); ?>">
        <div class="form-group">
            <label for="" class="text-capitalize text-info d-block">changing password is optional</label>
            <label for="old_password" class="text-capitalize">old password</label>
            <input type="password" name="old_password" class="form-control">
        </div>
        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <div class="form-group">
            <label for="new_password" class="text-capitalize">new password</label>
            <input type="password" name="new_password" class="form-control">
        </div>
        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <div class="form-group">
            <label for="re_new_password" class="text-capitalize">repeat new password</label>
            <input type="password" name="re_new_password" class="form-control">
        </div>
        <?php $__errorArgs = ['re_new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="actions d-flex align-items-center">
            
            <button class="text-capitalize btn btn-primary px-5 py-2">update</button>
        </div>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/admin/pages/updateProfile.blade.php ENDPATH**/ ?>