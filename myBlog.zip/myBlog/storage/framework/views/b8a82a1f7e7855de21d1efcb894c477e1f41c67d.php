<?php $__env->startSection('title'); ?> <?php echo e($searchName); ?> <?php $__env->stopSection(); ?>

<?php $hero__name = 'home__hero' ?>

<?php $__env->startSection('content'); ?>
<!-- blog section -->
<main class="blog__section">
    <!-- begin container -->
    <section class="container">
        <!-- begin row -->
        <div class="row flex-lg-nowrap flex-md-wrap">
            <!-- blog holder -->
            <div class="blog__holder p-0 col-lg-8 flex-md-12">
                <h3 class="w-100 p-3 bg-white shadow-sm mb-3 text-capitalize text-info" style="font-size: 1.2rem">term : <?php echo e($searchName); ?></h3>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- post 01 -->
                <div class="post__item bg-white shadow-sm">
                    <!-- post image -->
                    <div class="post__img">
                        <?php if($post->image != '0'): ?>
                        <img src="<?php echo e(asset('admin/posts/'.$post->image)); ?>" alt="post__img">
                        <?php else: ?>
                        <img src="<?php echo e(asset('home/img/bg.jpg')); ?>" alt="post__img">
                        <?php endif; ?>
                    </div>
                    <!-- post info -->
                    <div class="post__info w-100 d-flex align-items-center flex-wrap my-3">
                        <div class="date d-flex align-items-center pr-2">
                            <span class="icon mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                            <span class="text"><?php echo e($post->created_at); ?></span>
                        </div>
                        <div class="author d-flex align-items-center mx-lg-3 pr-sm-2">
                            <span class="icon mr-2"><ion-icon name="person-outline"></ion-icon></span>
                            <span class="text text-capitalize"><?php echo e($post->author); ?></span>
                        </div>
                        <div class="author d-flex align-items-center">
                            <span class="icon mr-2"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                            <span class="text text-capitalize">20 comments</span>
                        </div>
                        <div class="author d-flex align-items-center ml-3">
                            <span class="icon mr-2"><ion-icon name="pricetags-outline"></ion-icon></span>
                            <span class="text text-capitalize"><?php echo e($post->tag); ?></span>
                        </div>
                    </div>
                    <!-- post title -->
                    <h3 class="post__title text-capitalize"><?php echo e($post->title); ?></h3>
                    <!-- post body -->
                    <div class="post__body"><?php echo substr($post->body, 0, 150); ?></div>
                    <!-- read more button -->
                    <a href="<?php echo e(url('blog', [$post->slug])); ?>" class="read__more btn text-capitalize text-white d-flex align-items-center justify-content-center">read more</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($posts) < 1): ?>
                <div class="alert alert-info w-100 text-capitalize p-3">no posts found! ...</div>
                <?php endif; ?>
            </div>
            <?php echo $__env->make('home.includes.aside__container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div> <!-- end row -->

    </section> <!-- end container -->
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/pages/searchPost.blade.php ENDPATH**/ ?>