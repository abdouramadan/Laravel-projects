<!-- hero section -->
<section class="hero__section d-flex align-items-center justify-content-center position-relative">
    <div class="container">
        <div class="text__intro p-3 position-relative d-flex flex-column align-items-center justify-content-center">
            <h1 class="text-capitalize">welcome to our forum</h1>
            <!-- serach bar -->
            <form action="<?php echo e(route('Search')); ?>" method="POST" class="mt-4">
                <?php echo csrf_field(); ?>
                <div class="form-group d-flex align-items-center justify-content-center w-100 m-0">
                    <input type="text" name="s" class="form-control rounded-0" placeholder="search">
                    <button class="btn rounded-0 d-flex align-items-center justify-content-center p-0">
                        <span class="icon"><ion-icon name="search-outline"></ion-icon></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/home/includes/home__hero.blade.php ENDPATH**/ ?>