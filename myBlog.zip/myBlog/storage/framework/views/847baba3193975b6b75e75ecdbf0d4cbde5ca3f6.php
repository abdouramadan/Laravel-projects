<?php $__env->startSection('title'); ?> Signup <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="signup__page d-flex align-items-center justify-content-center">
        <form action="<?php echo e(route('Signup')); ?>" method="POST" class="rounded shadow">
            <?php echo csrf_field(); ?>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success text-capitalize w-100"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger text-capitalize w-100"><?php echo e(Session::get('error')); ?></div>
            <?php endif; ?>

            <h3 class="text-capitalize mb-3">create user account</h3>
            
            <div class="form-group">
                <label for="username" class="text-capitalize">username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            
            <div class="form-group">
                <label for="email" class="text-capitalize">email address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            
            <div class="form-group">
                <label for="password" class="text-capitalize">password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            
            <div class="form-group">
                <label for="re_password" class="text-capitalize">repeat password</label>
                <input type="password" name="re_password" class="form-control" required>
            </div>
            <?php $__errorArgs = ['re_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger text-capitalize w-100"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="actions d-flex align-items-center">
                
                <button class="text-capitalize btn btn-primary px-5 py-2">signup</button>
                <p class="p-0 m-0 mx-2 text-capitalize">you have account? - <a href="<?php echo e(route('Login')); ?>">login</a></p>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('accounts.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/accounts/pages/signup.blade.php ENDPATH**/ ?>