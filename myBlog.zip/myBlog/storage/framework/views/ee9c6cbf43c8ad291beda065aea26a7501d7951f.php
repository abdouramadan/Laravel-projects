<?php $__env->startSection('title'); ?> Profile <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="profile__page">
		<div class="bg-white p-3 shadow-sm">
            <h3 class="text-capitalize mb-3">profile informtion</h3>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-capitalize p-3"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
			<ul class="list-group">
				<li class="list-group-item d-flex align-items-center justify-content-between text-capitalize">
					<span>name</span>
					<span><?php echo e(Session::get('username')); ?></span>
				</li>
				<li class="list-group-item d-flex align-items-center justify-content-between">
					<span class="text-capitalize">email address</span>
					<span><?php echo e(Session::get('email')); ?></span>
				</li>
			</ul>
			<a href="<?php echo e(route('UpdateProfilePage', ['id'=>Session::get('id')])); ?>" class="update__profile__link mt-3 d-flex align-items-center justify-content-center text-capitalize text-decoration-none">update profile</a>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/admin/pages/profile.blade.php ENDPATH**/ ?>