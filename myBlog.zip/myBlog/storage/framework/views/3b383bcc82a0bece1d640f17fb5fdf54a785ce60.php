<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title> <?php echo $__env->yieldContent('title'); ?> </title>
	<link rel="dns-prefetch" href="//fonts.gstatic.com">
	<link rel="stylesheet" href="<?php echo e(asset('home/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/css/app.css')); ?>">
</head>
<body>

	
	<header class="top__navbar">
		<nav class="d-flex align-items-center justify-content-between pr-lg-3">
			<a href="<?php echo e(route('Home')); ?>" class="d-flex h-100 logo align-items-center justify-content-center text-capitalize text-decoration-none">abdoudev</a>
			<div class="user__nav text-capitalize h-100">
                <a href="<?php echo e(route('Logout')); ?>" class="text-white text-decoration-none">logout</a>
                <button class="toggle__navbar h-100 p-0 m-0 border-0">
                    <ion-icon name="menu-outline"></ion-icon>
                </button>
			</div>
		</nav>
	</header>

	
	<aside class="aside__navbar">
		
		<a href="<?php echo e(route('Admin')); ?>" class="nav__link active text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="speedometer-outline"></ion-icon></span>
			<span class="text text-capitalize">dashboard</span>
		</a>
		
		<a href="<?php echo e(route('Blog')); ?>" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="newspaper-outline"></ion-icon></span>
			<span class="text text-capitalize">blog</span>
		</a>
		
		<a href="<?php echo e(route('AddPost')); ?>" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="add-outline"></ion-icon></span>
			<span class="text text-capitalize">add post</span>
		</a>
		
		<a href="<?php echo e(route('Comments')); ?>" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="chatbubbles-outline"></ion-icon></span>
			<span class="text text-capitalize">comments</span>
		</a>
		
		<a href="<?php echo e(route('Messages')); ?>" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="mail-outline"></ion-icon></span>
			<span class="text text-capitalize">messages</span>
		</a>
		
		<a href="<?php echo e(route('Profile')); ?>" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="person-outline"></ion-icon></span>
			<span class="text text-capitalize">profile</span>
		</a>
		
		<a href="<?php echo e(route('Logout')); ?>" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="log-out-outline"></ion-icon></span>
			<span class="text text-capitalize">logout</span>
		</a>
	</aside>

	
	<main class="content__wrapper p-2"> <?php echo $__env->yieldContent('content'); ?> </main>

	<script src="https://cdn.ckeditor.com/ckeditor5/20.0.0/classic/ckeditor.js"></script>
	<script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	<script src="<?php echo e(asset('home/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('home/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/admin/layout/layout.blade.php ENDPATH**/ ?>