<?php $__env->startSection('title'); ?> Blog <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="blog__page">
		<div class="text__intro shadow d-inline-flex align-items-center mt-3">
			<span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="newspaper-outline"></ion-icon></span>
			<h3 class="text-capitalize p-0 m-0">all posts</h3>
		</div>

		
		<div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
			
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-capitalize w-100 p-3"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post col-lg-6 col-md-12 p-0 p-lg-2 p-sm-0">
				<div class="inner__item d-flex justify-content-between flex-wrap shadow-sm w-100">
					<div class="post__img w-100">
                        <?php if($post->image != '0'): ?>
                        <img src="<?php echo e(asset('admin/posts/'.$post->image)); ?>" class="w-100 h-100" alt="post image">
                        <?php else: ?>
						<img src="<?php echo e(asset('home/img/bg-2.jpg')); ?>" class="w-100 h-100" alt="post image">
                        <?php endif; ?>
					</div>
					<div class="w-100">
                        <!-- post info -->
                        <div class="post__info w-100 d-flex align-items-center my-3 flex-wrap">
                            <div class="date d-flex align-items-center">
                                <span class="icon mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                                <span class="text"><?php echo e($post->created_at); ?></span>
                            </div>
                            <div class="author d-flex align-items-center mr-md-2 mx-lg-3">
                                <span class="icon mr-2"><ion-icon name="person-outline"></ion-icon></span>
                                <span class="text text-capitalize"><?php echo e($post->author); ?></span>
                            </div>
                            <div class="author d-flex align-items-center">
                                <span class="icon mr-2"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                                <span class="text text-capitalize">20 comments</span>
                            </div>
                            <div class="author d-flex align-items-center mt-lg-2 ml-md-2">
                                <span class="icon d-flex align-items-center mr-2"><ion-icon name="pricetags-outline"></ion-icon></span>
                                <span class="text text-capitalize"><?php echo e($post->tag); ?></span>
                            </div>
                        </div>
                        <!-- post title -->
                        <h3 class="post__title text-capitalize"><?php echo e($post->title); ?></h3>
                        <!-- post body -->
                        <div class="post__body"> <?php echo substr($post->body,0,150); ?> </div>
                        
                        <div class="actions d-flex align-items-center mt-3">
                            <a href="<?php echo e(url('blog', [$post->slug])); ?>" class="action__link d-flex align-items-center text-capitalize">visit</a>
                            <a href="<?php echo e(route('DeletePost', ['id'=>$post->id])); ?>" class="action__link delete__post d-flex align-items-center text-danger text-capitalize mx-2">
                                <span class="icon d-flex align-items-center mr-1"><ion-icon name="trash-outline"></ion-icon></span>
                                <span>delete</span>
                            </a>
                            <a href="<?php echo e(route('UpdatePost', ['id'=>$post->id])); ?>" class="action__link update__post d-flex align-items-center text-info text-capitalize">
                                <span class="icon d-flex align-items-center mr-1"><ion-icon name="create-outline"></ion-icon></span>
                                <span>update</span>
                            </a>
                        </div>
                    </div>
				</div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($posts) < 1): ?>
            <div class="alert alert-info text-capitalize p-3 w-100">no posts availabel ...</div>
            <?php endif; ?>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdou_ramadan\Desktop\WEB\Components\one\laravel -v\myBlog\resources\views/admin/pages/blog.blade.php ENDPATH**/ ?>