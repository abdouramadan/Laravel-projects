<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Home Controller
|--------------------------------------------------------------------------
*/

Route::get('/', 'HomeController@index')->name('Home');
Route::get('/blog/cat/{cat}', 'HomeController@category')->name('Cat');
Route::post('/blog/search', 'HomeController@search')->name('Search');
Route::get('/blog/{slug}', 'HomeController@post')->name('Post');
Route::get('/contact', 'HomeController@contact')->name('Contact');
Route::get('/about', 'HomeController@about')->name('About');


/*
|--------------------------------------------------------------------------
| Admin Controller
|--------------------------------------------------------------------------
*/
Route::get('/MyCpanel', 'AdminController@index')->name('Admin');
Route::get('/MyCpanel/messages', 'AdminController@messages')->name('Messages');
Route::get('/MyCpanel/comments', 'AdminController@comments')->name('Comments');
Route::get('/MyCpanel/blog', 'AdminController@blog')->name('Blog');
Route::get('/MyCpanel/profile', 'AdminController@profile')->name('Profile');
Route::get('/MyCpanel/profile/update/{id}', 'AdminController@updateProfile')->name('UpdateProfilePage');
Route::get('/MyCpanel/blog/create', 'AdminController@addPost')->name('AddPost');
Route::get('/MyCpanel/blog/update/{id}', 'AdminController@updatePost')->name('UpdatePost');


/*
|--------------------------------------------------------------------------
| Accounts Controller
|--------------------------------------------------------------------------
*/
Route::get('/user/login', 'AccountsController@login')->name('Login');
Route::post('/user/login', 'AccountsController@enter')->name('Login');
// Route::get('/user/signup', 'AccountsController@signup')->name('Signup');
// Route::post('/user/signup', 'AccountsController@create')->name('Signup');
Route::put('/user/update/{id}', 'AccountsController@update')->name('UpdateProfile');
Route::get('/user/logout', 'AccountsController@logout')->name('Logout');


/*
|--------------------------------------------------------------------------
| Posts Controller
|--------------------------------------------------------------------------
*/
Route::post('/MyCpanel/blog/create', 'PostsController@create')->name('AddPost');
Route::get('/MyCpanel/blog/delete/{id}', 'PostsController@destroy')->name('DeletePost');
Route::post('/MyCpanel/blog/update/{id}', 'PostsController@update')->name('UpdatePost');

/*
|--------------------------------------------------------------------------
| Comments Controller
|--------------------------------------------------------------------------
*/
Route::post('/blog/comment/create/{id}', 'CommentsController@create')->name('CreateComment');
Route::get('/blog/comment/prove/{id}', 'CommentsController@prove')->name('ProveComment');
Route::get('/blog/comment/delete/{id}', 'CommentsController@delete')->name('DeleteComment');


