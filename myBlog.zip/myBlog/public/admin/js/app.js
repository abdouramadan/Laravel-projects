ClassicEditor.create(document.querySelector("#editor")).catch((error) => {
    console.error(error);
});

const toggleNavbarBtn = document.querySelector(".toggle__navbar");
const navbar = document.querySelector("aside.aside__navbar");

toggleNavbarBtn.addEventListener('click', function() {
    navbar.classList.toggle('toggleAsideNavbar');
});
