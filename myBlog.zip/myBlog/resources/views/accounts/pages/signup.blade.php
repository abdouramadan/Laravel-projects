@extends('accounts.layout.layout')

@section('title') Signup @endsection

@section('content')
    <main class="signup__page d-flex align-items-center justify-content-center">
        <form action="{{ route('Signup') }}" method="POST" class="rounded shadow">
            @csrf

            @if (Session::has('success'))
                <div class="alert alert-success text-capitalize w-100">{{ Session::get('success') }}</div>
            @endif

            @if (Session::has('error'))
                <div class="alert alert-danger text-capitalize w-100">{{ Session::get('error') }}</div>
            @endif

            <h3 class="text-capitalize mb-3">create user account</h3>
            {{-- username --}}
            <div class="form-group">
                <label for="username" class="text-capitalize">username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            @error('username')
                <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
            @enderror

            {{-- email --}}
            <div class="form-group">
                <label for="email" class="text-capitalize">email address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            @error('email')
                <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
            @enderror

            {{-- password --}}
            <div class="form-group">
                <label for="password" class="text-capitalize">password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            @error('password')
                <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
            @enderror

            {{-- re_password --}}
            <div class="form-group">
                <label for="re_password" class="text-capitalize">repeat password</label>
                <input type="password" name="re_password" class="form-control" required>
            </div>
            @error('re_password')
                <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
            @enderror

            <div class="actions d-flex align-items-center">
                {{-- submit button --}}
                <button class="text-capitalize btn btn-primary px-5 py-2">signup</button>
                <p class="p-0 m-0 mx-2 text-capitalize">you have account? - <a href="{{ route('Login') }}">login</a></p>
            </div>
        </form>
    </main>
@endsection
