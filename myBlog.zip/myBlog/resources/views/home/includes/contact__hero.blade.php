<!-- hero section -->
<section class="hero__section d-flex align-items-center justify-content-center position-relative">
    <div class="container">
        <div class="text__intro p-3 position-relative d-flex flex-column align-items-center justify-content-center">
            <h1 class="text-capitalize">be in touch with us</h1>
        </div>
    </div>
</section>
