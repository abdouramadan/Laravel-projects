@extends('home.layout.layout')

@section('title') Post Page @endsection

<?php $no__header_height = true; ?>


@section('content')
<!-- blog section -->
<main class="blog__section single__post">
    <section class="container">
        <div class="row flex-lg-nowrap flex-md-wrap">
            <!-- holder -->
            <div class="blog__holder p-0 col-lg-8 flex-md-12">
                @if (Session::has('success'))
                    <div class="alert alert-success text-capitalize-success">{{ Session::get('success') }}</div>
                @endif
                <!-- post 01 -->
                <div class="post bg-white shadow-sm">
                    <!-- post image -->
                    <div class="post__img">
                        @if ($post->image != '0')
                        <img src="{{ asset('admin/posts/'.$post->image) }}" alt="post__img">
                        @else
                        <img src="{{ asset('home/img/bg.jpg') }}" alt="post__img">
                        @endif
                    </div>
                    <!-- post info -->
                    <div class="post__info w-100 d-flex align-items-center flex-wrap my-3">
                        <div class="date d-flex align-items-center">
                            <span class="icon mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                            <span class="text">{{ $post->created_at }}</span>
                        </div>
                        <div class="author d-flex align-items-center mx-lg-3">
                            <span class="icon mr-2"><ion-icon name="person-outline"></ion-icon></span>
                            <span class="text text-capitalize">{{ $post->author }}</span>
                        </div>
                        <div class="author d-flex align-items-center">
                            <span class="icon mr-2"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                            <span class="text text-capitalize">20 comments</span>
                        </div>
                        <div class="author d-flex align-items-center ml-3">
                            <span class="icon mr-2"><ion-icon name="pricetags-outline"></ion-icon></span>
                            <span class="text text-capitalize">{{ $post->tag }}</span>
                        </div>
                    </div>
                    <!-- post title -->
                    <h3 class="post__title text-capitalize">{{ $post->title }}</h3>
                    <!-- post body -->
                    <div class="post__body">{!! $post->body !!}</div>
                    <!-- post footer -->
                    <div class="post__footer d-flex align-items-center mt-5">
                        <div class="post__tags d-flex align-items-center">
                            <h3 class="text-capitalize mr-3 p-0 mb-0">tags : </h3>
                            <ul class="tags__list d-flex align-items-center p-0 m-0">
                                <a href="{{ route('Cat', ['cat'=>$post->tag]) }}" class="tag__link d-flex align-items-center justify-content-center text-decoration-none">{{ $post->tag }}</a>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- comments container -->
                <div class="comments mt-5 shadow-sm">
                    <h3 class="text-capitalize mb-5">recent comments</h3>

                    <div class="comments__wrapper">
                        @foreach ($postComments as $comment)
                        <!-- comment 01 -->
                        <div class="comment__item d-flex align-items-start">
                            <!-- user image -->
                            <div class="commenter__img rounded-circle">
                                <img src="{{ asset('home/img/default-user.jpg') }}" class="w-100 h-100 rounded-circle" alt="">
                            </div>
                            <!-- comment info -->
                            <div class="comment__info pl-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <h4 class="commenter__name text-capitalize">{{ $comment->username }}</h4>
                                    <span class="comment__date text-capitalize d-flex align-items-center">
                                        <ion-icon name="calendar-outline" class="mr-2"></ion-icon>
                                        <small>{{ $comment->created_at }}</small>
                                    </span>
                                </div>
                                <div class="comment__body">{!! $comment->body !!}</div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>

                <!-- comment form -->
                <div class="comment__form bg-white mt-5 shadow-sm" id="form">
                    <h3 class="text-capitalize mb-3">leave comment</h3>

                    <form action="{{ route('CreateComment', ['id'=>$post->id]) }}" method="POST">
                        @csrf

                        <div class="form-group">
                            <label for="username" class="text-capitalize">sername</label>
                            <input type="text" name="username" class="form-control">
                        </div>
                        @error('username')
                        <div class="alert alert-danger text-capitalize">{{ $message }}</div>
                        @enderror

                        <div class="form-group">
                            <label for="email" class="text-capitalize">email address</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        @error('email')
                        <div class="alert alert-danger text-capitalize">{{ $message }}</div>
                        @enderror

                        <div class="form-group">
                            <label for="body" class="text-capitalize">comment body</label>
                            <textarea name="body" id="editor" class="form-control"></textarea>
                        </div>
                        @error('body')
                        <div class="alert alert-danger text-capitalize">{{ $message }}</div>
                        @enderror

                        <button class="d-flex align-items-center justify-content-center text-capitalize">post comment</button>
                    </form>
                </div>
            </div>
            @include('home.includes.aside__container')
        </div>
    </section>
</main>
@endsection
