@extends('admin.layout.layout')

@section('title') Messages @endsection

@section('content')
	<section class="messages__page">
		<div class="text__intro shadow d-inline-flex align-items-center mt-3">
			<span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="mail-outline"></ion-icon></span>
			<h3 class="text-capitalize p-0 m-0">all messages</h3>
		</div>

		{{-- content --}}
		<div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
			{{-- message 01 --}}
			<div class="message col-lg-6 col-md-12 pr-lg-2 p-0">
				<div class="inner__item p-3 shadow-sm bg-white w-100 d-flex align-items-center justify-content-between flex-wrap">
					<p class="name p-0 m-0 d-flex align-items-center text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
						<span>abdou ramadan</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
						<span>20 jan, 2019</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center w-100 my-2">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
						<span>abdoudev36@gmail.com</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center w-100 text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="document-outline"></ion-icon></span>
						<span>subject : i need to hire you.</span>
					</p>
					<div class="body mt-3">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit.
						Aliquid optio harum repudiandae neque minus atque voluptatibus cupiditate sint vel ipsum!
					</div>
					<a href="" class="delete__message__link shadow-sm mt-3 d-flex align-items-center justify-content-center text-capitalize text-decoration-none">delete</a>
				</div>
			</div>

			{{-- message 02 --}}
			<div class="message col-lg-6 col-md-12 pr-lg-2 p-0">
				<div class="inner__item p-3 shadow-sm bg-white w-100 d-flex align-items-center justify-content-between flex-wrap">
					<p class="name p-0 m-0 d-flex align-items-center text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
						<span>abdou ramadan</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
						<span>20 jan, 2019</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center w-100 my-2">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
						<span>abdoudev36@gmail.com</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center w-100 text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="document-outline"></ion-icon></span>
						<span>subject : i need to hire you.</span>
					</p>
					<div class="body mt-3">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit.
						Aliquid optio harum repudiandae neque minus atque voluptatibus cupiditate sint vel ipsum!
					</div>
					<a href="" class="delete__message__link shadow-sm mt-3 d-flex align-items-center justify-content-center text-capitalize text-decoration-none">delete</a>
				</div>
			</div>

			{{-- message 03 --}}
			<div class="message col-lg-6 col-md-12 pr-lg-2 p-0">
				<div class="inner__item p-3 shadow-sm bg-white w-100 d-flex align-items-center justify-content-between flex-wrap">
					<p class="name p-0 m-0 d-flex align-items-center text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
						<span>abdou ramadan</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
						<span>20 jan, 2019</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center w-100 my-2">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
						<span>abdoudev36@gmail.com</span>
					</p>
					<p class="date p-0 m-0 d-flex align-items-center w-100 text-capitalize">
						<span class="icon d-flex align-items-center mr-2"><ion-icon name="document-outline"></ion-icon></span>
						<span>subject : i need to hire you.</span>
					</p>
					<div class="body mt-3">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit.
						Aliquid optio harum repudiandae neque minus atque voluptatibus cupiditate sint vel ipsum!
					</div>
					<a href="" class="delete__message__link shadow-sm mt-3 d-flex align-items-center justify-content-center text-capitalize text-decoration-none">delete</a>
				</div>
			</div>
		</div>
	</section>
@endsection