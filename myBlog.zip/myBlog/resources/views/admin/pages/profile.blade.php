@extends('admin.layout.layout')

@section('title') Profile @endsection

@section('content')
	<section class="profile__page">
		<div class="bg-white p-3 shadow-sm">
            <h3 class="text-capitalize mb-3">profile informtion</h3>
            @if (Session::has('success'))
            <div class="alert alert-success text-capitalize p-3">{{ Session::get('success') }}</div>
            @endif
			<ul class="list-group">
				<li class="list-group-item d-flex align-items-center justify-content-between text-capitalize">
					<span>name</span>
					<span>{{ Session::get('username') }}</span>
				</li>
				<li class="list-group-item d-flex align-items-center justify-content-between">
					<span class="text-capitalize">email address</span>
					<span>{{ Session::get('email') }}</span>
				</li>
			</ul>
			<a href="{{ route('UpdateProfilePage', ['id'=>Session::get('id')]) }}" class="update__profile__link mt-3 d-flex align-items-center justify-content-center text-capitalize text-decoration-none">update profile</a>
		</div>
	</section>
@endsection
