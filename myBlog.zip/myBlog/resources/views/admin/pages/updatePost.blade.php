@extends('admin.layout.layout')

@section('title') Update Post @endsection

@section('content')
	<section class="addPost__page p-lg-4 p-sm-1">
		<div class="text__intro shadow d-inline-flex align-items-center mt-4">
			<span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="newspaper-outline"></ion-icon></span>
			<h3 class="text-capitalize p-0 m-0">update post</h3>
		</div>

		<form action="{{ route('UpdatePost', ['id'=>$post->id]) }}" method="POST" class="p-3 shadow mt-5" enctype="multipart/form-data">
            @csrf
            @if (Session::has('success'))
            <div class="alert alert-success text-capitalize">{{ Session::get('success') }}</div>
            @endif
			{{-- post title --}}
			<div class="form-group">
				<label for="title">post title</label>
				<input type="text" name="title" class="form-control" value="{{ $post->title }}">
            </div>
            @error('title')
                <div class="alert alert-danger text-capitalize">{{ $message }}</div>
            @enderror

			{{-- post tag --}}
			<div class="form-group">
				<label for="title">post tag</label>
				<select name="tag" class="form-control">
					<option value="{{ $post->tag }}">{{ $post->tag }}</option>
					<option value="web design">web design</option>
					<option value="programming">programming</option>
					<option value="news">news</option>
					<option value="culture">culture</option>
					<option value="fun">fun</option>
					<option value="religion">religion</option>
					<option value="education">education</option>
					<option value="english">english</option>
					<option value="others">others</option>
				</select>
            </div>
            @error('tag')
                <div class="alert alert-danger text-capitalize">{{ $message }}</div>
            @enderror

			{{-- post image --}}
			<div class="form-group">
				<label for="image">post image</label>
				<input type="file" name="image" class="form-control">
            </div>
            @error('image')
                <div class="alert alert-danger text-capitalize">{{ $message }}</div>
            @enderror

			{{-- post body --}}
			<div class="form-group">
				<label for="body">post body</label>
				<textarea name="body" id="editor" class="form-control">{{ $post->body }}</textarea>
            </div>
            @error('body')
                <div class="alert alert-danger text-capitalize">{{ $message }}</div>
            @enderror

			<button class="submit__btn">update</button>
		</form>
	</section>
@endsection
