@extends('admin.layout.layout')

@section('title') Update Profile @endsection

@section('content')
<main class="update__profile p-lg-4">
    <form action="{{ route('UpdateProfile', ['id'=>Session::get('id')]) }}" method="POST" class="rounded shadow bg-white p-3">
        @csrf

        @method('PUT')

        @if (Session::has('success'))
            <div class="alert alert-success text-capitalize w-100">{{ Session::get('success') }}</div>
        @endif

        @if (Session::has('error'))
            <div class="alert alert-danger text-capitalize w-100">{{ Session::get('error') }}</div>
        @endif

        <h3 class="text-capitalize mb-3">update user account</h3>
        {{-- username --}}
        <div class="form-group">
            <label for="username" class="text-capitalize">username</label>
            <input type="text" name="username" class="form-control" value="{{ Session::get('username') }}" required>
        </div>
        @error('username')
            <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
        @enderror

        {{-- email --}}
        <div class="form-group">
            <label for="email" class="text-capitalize">email address</label>
            <input type="email" name="email" class="form-control" value="{{ Session::get('email') }}" required>
        </div>
        @error('email')
            <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
        @enderror

        {{-- password --}}
        <input type="hidden" name="hidden_password" value="{{ Session::get('password') }}">
        <div class="form-group">
            <label for="" class="text-capitalize text-info d-block">changing password is optional</label>
            <label for="old_password" class="text-capitalize">old password</label>
            <input type="password" name="old_password" class="form-control">
        </div>
        @error('old_password')
            <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
        @enderror

        {{-- new_password --}}
        <div class="form-group">
            <label for="new_password" class="text-capitalize">new password</label>
            <input type="password" name="new_password" class="form-control">
        </div>
        @error('new_password')
            <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
        @enderror

        {{-- re_new_password --}}
        <div class="form-group">
            <label for="re_new_password" class="text-capitalize">repeat new password</label>
            <input type="password" name="re_new_password" class="form-control">
        </div>
        @error('re_new_password')
            <div class="alert alert-danger text-capitalize w-100">{{ $message }}</div>
        @enderror

        <div class="actions d-flex align-items-center">
            {{-- submit button --}}
            <button class="text-capitalize btn btn-primary px-5 py-2">update</button>
        </div>
    </form>
</main>
@endsection
