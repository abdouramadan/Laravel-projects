@extends('admin.layout.layout')

@section('title') Comments @endsection

@section('content')
	<section class="comments__page">
		<div class="text__intro shadow d-inline-flex align-items-center mt-3">
			<span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="chatbubbles-outline"></ion-icon></span>
			<h3 class="text-capitalize p-0 m-0">all comments</h3>
        </div>
        @if (Session::has('success'))
            <div class="alert alert-success text-capitalize mt-3 p-3">{{ Session::get('success') }}</div>
        @endif

		{{-- content --}}
		<div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
            @foreach ($comments as $comment)
            {{-- comment 01 --}}
            <div class="comment col-lg-6 col-md-12 p-0 p-lg-2 p-sm-0">
                <div class="inner__item w-100 p-3 shadow-sm bg-white">
                    <div class="comment-info d-flex align-items-center justify-content-between flex-wrap">
                        <p class="name text-capitalize p-0 m-0 d-flex align-items-center">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
                            <span>{{ $comment->username }}</span>
                        </p>
                        <p class="date p-0 m-0 d-flex align-items-center">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                            <span>{{ $comment->created_at }}</span>
                        </p>
                        <p class="email p-0 m-0 d-flex align-content-around w-100 mt-2">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
                            <span>{{ $comment->email }}</span>
                        </p>
                        <div class="body my-3 w-100">{!! $comment->body !!}</div>
                        <div class="actions d-flex align-items-center">
                            @if ($comment->status == '1')
							<a href="{{ url('blog', [$comment->post_slug]) }}" class="action__link visit__comment d-flex align-items-center justify-content-center text-capitalize text-decoration-none">visit</a>
                            @endif
							<a href="{{ route('DeleteComment', ['id'=>$comment->id]) }}" class="action__link delete__comment d-flex align-items-center justify-content-center text-capitalize text-decoration-none mx-2">delete</a>
                            @if ($comment->status == '0')
							<a href="{{ route('ProveComment', ['id'=>$comment->id]) }}" class="action__link upprove__comment d-flex align-items-center justify-content-center text-capitalize text-decoration-none">upprove</a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            @endforeach

            @if (count($comments) < 1)
            <div class="alert alert-info text-capitalize w-100 p-3">no comments found</div>
            @endif
		</div>
	</section>
@endsection
