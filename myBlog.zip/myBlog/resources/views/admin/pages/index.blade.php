@extends('admin.layout.layout')

@section('title') Dashboard @endsection

@section('content')
<section class="dashboard">
    {{-- count items --}}
    <div class="count__items w-100 d-flex align-items-center justify-content-between flex-wrap p-0 m-0">

        {{-- count posts --}}
        <div class="item col-lg-4 col-md-6 col-sm-12 p-0">
            <div class="inner__item w-100 d-flex align-items-center justify-content-between p-3">
                <div class="text">
                    <span class="icon d-flex align-items-center"><ion-icon name="newspaper-outline"></ion-icon></span>
                    <h3 class="text-capitalize m-0 p-0 mt-2">all news</h3>
                </div>
                <div class="number">
                    <span class="rounded-circle d-flex align-items-center justify-content-center">{{ count($countPosts) }}</span>
                </div>
            </div>
        </div>

        {{-- count comments --}}
        <div class="item col-lg-4 col-md-6 col-sm-12 p-0 px-lg-2 pl-md-2">
            <div class="inner__item w-100 d-flex align-items-center justify-content-between p-3">
                <div class="text">
                    <span class="icon d-flex align-items-center"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                    <h3 class="text-capitalize m-0 p-0 mt-2">all comments</h3>
                </div>
                <div class="number">
                    <span class="rounded-circle d-flex align-items-center justify-content-center">{{ count($countComments) }}</span>
                </div>
            </div>
        </div>

        {{-- count pinned cooments --}}
        <div class="item col-lg-4 col-md-6 col-sm-12 p-0 pr-md-2">
            <div class="inner__item w-100 d-flex align-items-center justify-content-between p-3">
                <div class="text">
                    <span class="icon d-flex align-items-center"><ion-icon name="chatbubble-ellipses-outline"></ion-icon></span>
                    <h3 class="text-capitalize m-0 p-0 mt-2">pinned comments</h3>
                </div>
                <div class="number">
                    <span class="rounded-circle d-flex align-items-center justify-content-center">{{ count($pinnedComments) }}</span>
                </div>
            </div>
        </div>

        {{-- count messages --}}
        <div class="item col-lg-4 col-md-6 col-sm-12 p-0">
            <div class="inner__item w-100 d-flex align-items-center justify-content-between p-3">
                <div class="text">
                    <span class="icon d-flex align-items-center"><ion-icon name="mail-open-outline"></ion-icon></span>
                    <h3 class="text-capitalize m-0 p-0 mt-2">messages</h3>
                </div>
                <div class="number">
                    <span class="rounded-circle d-flex align-items-center justify-content-center">22</span>
                </div>
            </div>
        </div>
    </div>

    {{-- latest news --}}
    <div class="latest__posts mt-3">
        <div class="text__intro shadow d-inline-flex align-items-center">
            <span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="newspaper-outline"></ion-icon></span>
            <h3 class="text-capitalize p-0 m-0">latest news posts</h3>
        </div>

        {{-- content --}}
        <div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
            @foreach ($posts as $post)
                {{-- post 01 --}}
                <div class="post col-lg-6 col-md-12 p-0 p-lg-2 p-sm-0">
                    <div class="inner__item d-flex justify-content-between flex-wrap shadow-sm w-100">
                        <div class="post__img w-100">
                            @if ($post->image != '0')
                            <img src="{{ asset('admin/posts/'.$post->image) }}" class="w-100 h-100" alt="post image">
                            @else
                            <img src="{{ asset('home/img/bg-2.jpg') }}" class="w-100 h-100" alt="post image">
                            @endif
                        </div>
                        <div class="w-100">
                            <!-- post info -->
                            <div class="post__info w-100 d-flex align-items-center flex-wrap my-3">
                                <div class="date d-flex align-items-center">
                                    <span class="icon mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                                    <span class="text">{{ $post->created_at }}</span>
                                </div>
                                <div class="author d-flex align-items-center mx-lg-3">
                                    <span class="icon mr-2"><ion-icon name="person-outline"></ion-icon></span>
                                    <span class="text text-capitalize">{{ $post->author }}</span>
                                </div>
                                <div class="author d-flex align-items-center">
                                    <span class="icon mr-2"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                                    <span class="text text-capitalize">20 comments</span>
                                </div>
                                <div class="author d-flex align-items-center ml-3">
                                    <span class="icon mr-2"><ion-icon name="pricetags-outline"></ion-icon></span>
                                    <span class="text text-capitalize">{{ $post->tag }}</span>
                                </div>
                            </div>
                            <!-- post title -->
                            <h3 class="post__title text-capitalize">{{ $post->title }}</h3>
                            <!-- post body -->
                            <div class="post__body">{!! substr($post->body,0,150) !!}</div>
                            <!-- read more button -->
                            <a href="{{ url('blog', [$post->slug]) }}" class="read__more btn text-capitalize text-white d-flex align-items-center justify-content-center">read more</a>
                        </div>
                    </div>
                </div>
            @endforeach

            @if (count($posts) < 1)
            <div class="alert alert-info text-capitalize p-3 w-100">no posts availabel ...</div>
            @endif
        </div>
    </div>

    {{-- latest comments --}}
    <div class="latest__comments mt-3">
        <div class="text__intro shadow d-inline-flex align-items-center">
            <span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="chatbubbles-outline"></ion-icon></span>
            <h3 class="text-capitalize p-0 m-0">latest comments</h3>
        </div>

        {{-- content --}}
        <div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
            @foreach ($comments as $comment)
            {{-- comment 01 --}}
            <div class="comment col-lg-6 col-md-12 p-0 p-lg-2 p-sm-0">
                <div class="inner__item w-100 p-3 shadow-sm bg-white">
                    <div class="comment-info d-flex align-items-center justify-content-between flex-wrap">
                        <p class="name text-capitalize p-0 m-0 d-flex align-items-center">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
                            <span>{{ $comment->username }}</span>
                        </p>
                        <p class="date p-0 m-0 d-flex align-items-center">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                            <span>{{ $comment->created_at }}</span>
                        </p>
                        <p class="email p-0 m-0 d-flex align-content-around w-100 mt-2">
                            <span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
                            <span>{{ $comment->email }}</span>
                        </p>
                        <div class="body my-3 w-100">{!! substr($comment->body, 0, 200) !!}</div>
                        <a href="{{ url('blog', [$comment->post_slug]) }}" class="comment__page__link d-flex align-items-center justify-content-center text-capitalize text-decoration-none">visit comment page</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    {{-- latest messages --}}
    <div class="latest__messages mt-3">
        <div class="text__intro shadow d-inline-flex align-items-center">
            <span class="icon mr-2 d-flex align-items-center justify-content-center"><ion-icon name="mail-outline"></ion-icon></span>
            <h3 class="text-capitalize p-0 m-0">latest messages</h3>
        </div>

        {{-- content --}}
        <div class="content mt-4 d-flex align-items-start justify-content-between flex-wrap">
            {{-- message 01 --}}
            <div class="message col-lg-6 col-md-12 pr-lg-2 p-0">
                <div class="inner__item p-3 shadow-sm bg-white w-100 d-flex align-items-center justify-content-between flex-wrap">
                    <p class="name p-0 m-0 d-flex align-items-center text-capitalize">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
                        <span>abdou ramadan</span>
                    </p>
                    <p class="date p-0 m-0 d-flex align-items-center text-capitalize">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                        <span>20 jan, 2019</span>
                    </p>
                    <p class="date p-0 m-0 d-flex align-items-center w-100 my-2">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
                        <span>abdoudev36@gmail.com</span>
                    </p>
                    <p class="date p-0 m-0 d-flex align-items-center w-100 text-capitalize">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="document-outline"></ion-icon></span>
                        <span>subject : i need to hire you.</span>
                    </p>
                    <div class="body mt-3">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                        Aliquid optio harum repudiandae neque minus atque voluptatibus cupiditate sint vel ipsum!
                    </div>
                </div>
            </div>

            {{-- message 02 --}}
            <div class="message col-lg-6 col-md-12 pr-lg-2 p-0">
                <div class="inner__item p-3 shadow-sm bg-white w-100 d-flex align-items-center justify-content-between flex-wrap">
                    <p class="name p-0 m-0 d-flex align-items-center text-capitalize">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="person-outline"></ion-icon></span>
                        <span>abdou ramadan</span>
                    </p>
                    <p class="date p-0 m-0 d-flex align-items-center text-capitalize">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="calendar-outline"></ion-icon></span>
                        <span>20 jan, 2019</span>
                    </p>
                    <p class="date p-0 m-0 d-flex align-items-center w-100 my-2">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="mail-outline"></ion-icon></span>
                        <span>abdoudev36@gmail.com</span>
                    </p>
                    <p class="date p-0 m-0 d-flex align-items-center w-100 text-capitalize">
                        <span class="icon d-flex align-items-center mr-2"><ion-icon name="document-outline"></ion-icon></span>
                        <span>subject : i need to hire you.</span>
                    </p>
                    <div class="body mt-3">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                        Aliquid optio harum repudiandae neque minus atque voluptatibus cupiditate sint vel ipsum!
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
