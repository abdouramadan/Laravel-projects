<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title> @yield('title') </title>
	<link rel="dns-prefetch" href="//fonts.gstatic.com">
	<link rel="stylesheet" href="{{ asset('home/css/bootstrap.min.css') }}">
	<link rel="stylesheet" href="{{ asset('admin/css/app.css') }}">
</head>
<body>

	{{-- top navbar --}}
	<header class="top__navbar">
		<nav class="d-flex align-items-center justify-content-between pr-lg-3">
			<a href="{{ route('Home') }}" class="d-flex h-100 logo align-items-center justify-content-center text-capitalize text-decoration-none">abdoudev</a>
			<div class="user__nav text-capitalize h-100">
                <a href="{{ route('Logout') }}" class="text-white text-decoration-none">logout</a>
                <button class="toggle__navbar h-100 p-0 m-0 border-0">
                    <ion-icon name="menu-outline"></ion-icon>
                </button>
			</div>
		</nav>
	</header>

	{{-- aside navbar --}}
	<aside class="aside__navbar">
		{{-- link 1 --}}
		<a href="{{ route('Admin') }}" class="nav__link active text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="speedometer-outline"></ion-icon></span>
			<span class="text text-capitalize">dashboard</span>
		</a>
		{{-- link 2 --}}
		<a href="{{ route('Blog') }}" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="newspaper-outline"></ion-icon></span>
			<span class="text text-capitalize">blog</span>
		</a>
		{{-- link 3 --}}
		<a href="{{ route('AddPost') }}" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="add-outline"></ion-icon></span>
			<span class="text text-capitalize">add post</span>
		</a>
		{{-- link 4 --}}
		<a href="{{ route('Comments') }}" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="chatbubbles-outline"></ion-icon></span>
			<span class="text text-capitalize">comments</span>
		</a>
		{{-- link 5 --}}
		<a href="{{ route('Messages') }}" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="mail-outline"></ion-icon></span>
			<span class="text text-capitalize">messages</span>
		</a>
		{{-- link 6 --}}
		<a href="{{ route('Profile') }}" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="person-outline"></ion-icon></span>
			<span class="text text-capitalize">profile</span>
		</a>
		{{-- link 7 --}}
		<a href="{{ route('Logout') }}" class="nav__link text-decoration-none d-flex align-items-center w-100 pl-2">
			<span class="icon mr-2 d-flex align-items-baseline"><ion-icon name="log-out-outline"></ion-icon></span>
			<span class="text text-capitalize">logout</span>
		</a>
	</aside>

	{{-- content wrapper --}}
	<main class="content__wrapper p-2"> @yield('content') </main>

	<script src="https://cdn.ckeditor.com/ckeditor5/20.0.0/classic/ckeditor.js"></script>
	<script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
	<script src="{{ asset('home/js/jquery.min.js') }}"></script>
	<script src="{{ asset('home/js/popper.min.js') }}"></script>
	<script src="{{ asset('home/js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('admin/js/app.js') }}"></script>
</body>
</html>
