<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Post;
use Illuminate\Http\Request;

class CommentsController extends Controller
{
    // CREATE COMMENT
    public function create(Request $request, $id)
    {
        $post = Post::findOrFail($id);

        $comm = new Comment();

        $request->validate([
            'username' => 'required',
            'email' => 'email:filter|required',
            'body' => 'required',
        ]);

        $comm->username = $request->username;
        $comm->email = $request->email;
        $comm->body = $request->body;
        $comm->post_id = $post->id;
        $comm->post_slug = $post->slug;
        $comm->status = "0";

        $comm->save();

        return redirect()
        ->route('Post', $post->slug)
        ->withSuccess('your comment has posted successfully, please wait for admin to prove it ...');
    }

    // PROVE COMMENT
    public function prove($id)
    {
        $comm = Comment::find($id);

        $comm->status = "1";

        $comm->update(['id', $comm->id]);

        return redirect()->route('Comments')->withSuccess('comment proved successfully ...');
    }

    // DELETE COMMENT
    public function delete($id)
    {
        $comm = Comment::find($id);

        $comm->delete();

        return redirect()->route('Comments')->withSuccess('comment deleted successfully ...');
    }
}
