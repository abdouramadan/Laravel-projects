<?php

namespace App\Http\Controllers;

use App\Client;
use Illuminate\Http\Request;

class AccountsController extends Controller
{
    // LOGIN PAGE
    public function login(Request $request)
    {
        if($request->session()->has(['id', 'username', 'email', 'password'])) {
            return redirect()->route('Admin');
        }

        return view('accounts.pages.login');
    }

    /* SIGNUP PAGE
    public function signup()
    {
        return view('accounts.pages.signup');
    } */

    /* CREATE ACCOUNT
    public function create(Request $request)
    {
        $request->validate([
            'username' => 'required|max:20|min:4|unique:clients,username',
            'email' => 'required|email:filter|unique:clients,email',
            'password' => 'required|min:6|max:15',
            're_password' => 'required_with:password|same:password'
        ]);

        $user = new Client();

        $user->username = strtolower($request->username);
        $user->email = strtolower($request->email);
        $user->password = password_hash($request->password, PASSWORD_DEFAULT);

        $user->save();

        return redirect('/login')->withSucess('account created successfully ...');
    } */

    // LOG USER IN
    public function enter(Request $request)
    {
        $request->validate([
            'email' => 'required|email:filter',
            'password' => 'required'
        ]);

        $user = Client::where('email', $request->email);

        $password = password_verify($request->password, $user->value('password'));

        if($user->value('email') === $request->email AND $password )
        {
            $request->session()->put([
                'id' => $user->value('id'),
                'username' => $user->value('username'),
                'password' => $user->value('password'),
                'email' => $user->value('email'),
                ]);

            return redirect('/MyCpanel')->withSucess('login success ...');

        } else if($user->value('email') === $request->email AND !$password)
        {
            return redirect()->refresh()->withError('invalid password ...');

        } else if($user->value('email') !== $request->email)
        {
            return redirect()->refresh()->withError('there is no user with this account ...');

        } else {
            return redirect()->refresh()->withError('oops something went wrong please try again ...');
        }
    }

    // UPDATE USER ACCOUNT
    public function update(Request $request, $id)
    {
        $request->validate([
            'username' => 'required|max:20|min:4|unique:clients,username,'.$id.',id',
            'email' => 'required|email:filter|unique:clients,email,'.$id.',id',
        ]);

        $user = Client::findOrFail($id);

        $user->username = $request->username;
        $user->email = $request->email;

        if($request->old_password != '')
        {
            $realPass = password_verify($request->old_password, $user->password);

            if(!$realPass) {
                return redirect()->back()->withError('old password is not correct');
            } else {
                $request->validate([
                    'new_password' => 'required|min:6|max:15',
                    're_new_password' => 'required_with:new_password|same:new_password',
                ]);
            }

            $user->password = password_hash($request->new_password, PASSWORD_DEFAULT);

            $request->session()->put([
                'password' => $user->password,
                ]);
        }

        $request->session()->put([
            'id' => $user->id,
            'username' => $user->username,
            'email' => $user->email,
            ]);

        $user->update(['id' => $user->id]);

        return redirect()->route('Profile')->withSuccess('profile updated successfully ...');

    }

    // LOGOUT
    public function logout(Request $request)
    {
        $request->session()->forget(['id', 'username', 'password', 'email']);
        return redirect()->back();
    }
}
