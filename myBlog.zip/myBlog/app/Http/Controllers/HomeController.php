<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Post;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    // HOME PAGE
    public function index()
    {
        $posts = Post::orderBy('created_at', 'desc')->get();
        $latestPosts = Post::orderBy('created_at', 'desc')->take(3)->get();
        return view('home.pages.index', compact('posts', 'latestPosts'));
    }

    // SINGLE BLOG PAGE
    public function post($slug)
    {
        $latestPosts = Post::orderBy('created_at', 'desc')->take(3)->get();
        $postSlug = Post::where('slug', $slug);
        $post = Post::findOrFail($postSlug->value('id'));

        $postComments = Comment::where('post_id', $post->id)->orderBy('created_at', 'desc')->get();

        return view('home.pages.post', compact('post', 'latestPosts', 'postComments'));
    }

    // SHOW CATEGORY PAGE
    public function category($cat)
    {
        $cats = trim($cat);

        $cats = Post::where('tag', $cats)->orderBy('created_at', 'desc')->get();

        $latestPosts = Post::orderBy('created_at', 'desc')->take(3)->get();

        $catName = trim($cat);

        return view('home.pages.cats', compact('cats', 'latestPosts', 'catName'));
    }

    // SEARCH POST PAGE
    public function search(Request $request)
    {
        $s = trim($request->s);

        $posts = Post::where('title','like', '%'.$s.'%')->orderBy('created_at', 'desc')->get();

        $latestPosts = Post::orderBy('created_at', 'desc')->take(3)->get();

        $searchName = trim($s);

        return view('home.pages.searchPost', compact('posts', 'latestPosts', 'searchName'));
    }

    // CONTACT PAGE
    public function contact()
    {
        return view('home.pages.contact');
    }

    // ABOUT PAGE
    public function about()
    {
        return view('home.pages.about');
    }
}
