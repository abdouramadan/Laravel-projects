<?php

namespace App\Http\Controllers;

use App\Post;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Comment;

class PostsController extends Controller
{
    // CREATE POST
    public function create(Request $request)
    {
        $request->validate([
            'title' => 'required|unique:posts,title',
            'tag' => 'required',
            'body' => 'required'
        ]);

        $post = new Post();

        $post->title = $request->title;
        $post->tag = $request->tag;
        $post->body = $request->body;
        $post->image = "0";
        $post->author = $request->session()->get('username');
        $post->slug = Str::slug($request->title, '-');

        if($request->hasFile('image'))
        {
            $request->validate([
                'image' => 'image|mimes:jpg,jpeg,png,svg,gif|max:4024'
            ]);

            $date = Carbon::now();

            $image = sha1($date).$request->image->getClientOriginalName();

            $post->image = $image;

            $request->image->move(public_path('admin/posts'), $image);
        }

        $post->save();

        return redirect()->refresh()->withSuccess('post created successfully ...');
    }

    /* DELETE NEWS */
    public function destroy($id)
    {
        $post = Post::findOrFail($id);

        $comments = Comment::where('post_id', $post->id)->get(['id']);

        $img = public_path('admin/posts') . '/' . $post['image'];

        if (file_exists($img)) {

            @unlink($img);
        }

        Comment::destroy($comments->toArray());

        $post->delete();

        return redirect()->back()->withSuccess('post deleted successfully ...');
    }

    // UPDATE NEWS
    public function update(Request $request, $id)
    {
        $post = Post::findOrFail($id);

        $request->validate([
            'title' => 'required|min:3|max:200|unique:posts,title,'.$post->id.',id',
            'tag' => 'required',
            'body' => 'required'
        ]);

        $post->title = $request->title;
        $post->tag = $request->tag;
        $post->body = $request->body;
        $post->image = $post->image;
        $post->author = $request->session()->get('username');
        $post->slug = Str::slug($request->title, '-');

        if($request->hasFile('image'))
        {
            $request->validate([
                'image' => 'image|mimes:jpg,jpeg,png,svg,gif|max:4024'
            ]);

            $date = Carbon::now();

            $prevPostImage = $post->image;

            $image = sha1($date).$request->image->getClientOriginalName();

            $post->image = $image;

            $prevImg = public_path('admin/posts') . '/' . $prevPostImage;

            if (file_exists($prevImg)) {

                @unlink($prevImg);
            }

            $request->image->move(public_path('admin/posts'), $image);
        }

        $post->update(['id' => $id]);

        return redirect()->refresh()->withSuccess('post updated successfully ...');
    }
}
