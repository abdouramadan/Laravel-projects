<?php

namespace App\Http\Controllers;

use App\Client;
use App\Comment;
use App\Post;

class AdminController extends Controller
{
    function __construct()
    {
        $this->middleware('AdminAuth');
    }
    // ADMIN MAIN PAGE
    public function index()
    {
        $comments = Comment::where('status', '1')->orderBy('created_at', 'desc')->take(2)->get();
        $countComments = Comment::all();
        $pinnedComments = Comment::where('status', '0')->get();

        $posts = Post::orderBy('created_at', 'desc')->take(2)->get();
        $countPosts = Post::all();

        return View('admin.pages.index', compact('posts', 'countPosts', 'comments', 'countComments', 'pinnedComments'));
    }

    // MESSAGES PAGE
    public function messages()
    {
        return View('admin.pages.messages');
    }

    // COMMENTS PAGE
    public function comments()
    {
        $comments = Comment::orderBy('created_at', 'desc')->get();
        return View('admin.pages.comments', compact('comments'));
    }

    // BLOG PAGE
    public function blog()
    {
        $posts = Post::orderBy('created_at', 'desc')->get();
        return View('admin.pages.blog', compact('posts'));
    }

    // PROFILE PAGE
    public function profile()
    {
        return View('admin.pages.profile');
    }

    // UPDATE PROFILE PAGE
    public function updateProfile($id)
    {
        $user = Client::find($id);
        return View('admin.pages.updateProfile', compact('user'));
    }

    // ADD POST PAGE
    public function addPost()
    {
        return View('admin.pages.addPost');
    }

    // ADD POST PAGE
    public function updatePost($id)
    {
        $post = Post::findOrFail($id);
        return View('admin.pages.updatePost', compact('post'));
    }
}
